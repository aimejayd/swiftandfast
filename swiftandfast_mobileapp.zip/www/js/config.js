var krms_config ={		
	'ApiUrl':"https://swiftandfast.com/mobileapp/api",				
	'DialogDefaultTitle':"Swift and Fast",	
	'APIHasKey':"SWIFT463d5030654608c96d2592238a5453a7FAST",
	'debug': false
};